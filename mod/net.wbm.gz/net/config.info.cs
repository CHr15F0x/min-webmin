hosts_file=Soubor se seznamem hostů a adres,0
ipnodes_file=Soubor se seznamem IPv6 hostů a adres,0
def_netmask=Výchozí maska sítě,0
def_broadcast=Výchozí broadcast adresa,0
def_mtu=Výchozí MTU,0
