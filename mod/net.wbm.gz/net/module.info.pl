desc_pl=Konfiguracja sieci
longdesc_pl=Konfiguracja uruchamianych i aktywnych interfejsów, DNS, trasowania i /etc/hosts.
