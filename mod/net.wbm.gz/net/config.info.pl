hosts_file=Plik z nazwami i adresami hostów <tt>hosts</tt>,0
ipnodes_file=Plik z nazwami i adresami hostów <tt>hosts</tt> IPv6,0
def_netmask=Domyślna maska podsieci,0
def_broadcast=Domyślny adres rozgłaszania,0
def_mtu=Domyślne MTU,0
