inittab_file=Ścieżka do pliku inittab,0
