line2=Konfigurace systému,11
inittab_file=Cesta k souboru inittab,0
telinit=Cesta k příkazu telinit,0
